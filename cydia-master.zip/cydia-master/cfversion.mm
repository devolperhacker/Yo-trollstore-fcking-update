#include <CoreFoundation/CoreFoundation.h>
#include <cstdio>

int main() {
    printf("%.2f\n", kCFCoreFoundationVersionNumber);
    return 0;
}
