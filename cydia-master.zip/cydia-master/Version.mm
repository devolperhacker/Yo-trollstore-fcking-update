#include <Foundation/Foundation.h>
#include "Version.h"
NSString *Cydia_ = @ CYDIA_VERSION;
