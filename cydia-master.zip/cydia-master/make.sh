#!/bin/bash
DEVELOPER_DIR=/Applications/Xcode-5.1.1.app make "$@" do32=yes
